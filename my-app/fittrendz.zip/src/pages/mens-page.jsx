import Navbar from "../components/Navbar";
import Footer from "../components/footer";

export default function About() {
  return (
    <>
      <h2>Mens Page</h2>
    </>
  );
}
